from sklearn.metrics.pairwise import cosine_similarity

class RecommenderAgent:
    def __init__(self, books, book_embeddings):
        self.books = books
        self.book_embeddings = book_embeddings

    def recommend(self, user_vector, top_n=5):
        similarities = cosine_similarity([user_vector], self.book_embeddings)[0]
        scored_books = [(book, score) for book, score in zip(self.books, similarities) if book['description']]
        scored_books.sort(key=lambda x: x[1], reverse=True)
        
        recommended = []
        seen_titles = set() #for the duplicates issue
        
        for book, score in scored_books:
            title_lower = book['title'].strip().lower()
            if title_lower not in seen_titles:
                recommended.append(book)
                seen_titles.add(title_lower)
            if len(recommended) == top_n:
                break
        
        return recommended
