from sentence_transformers import SentenceTransformer
import numpy as np
from keybert import KeyBERT
import re
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

class ProfilerAgent:
    def __init__(self, model_name):
        self.model = SentenceTransformer(model_name)
        self.kw_model = KeyBERT(model=self.model)

    def generate_user_vector(self, descriptions: list[str]) -> np.ndarray:
        embeddings = self.model.encode(descriptions)
        return embeddings.mean(axis=0)

    def extract_keywords(self, descriptions: list[str], top_k=5):
        text = " ".join(descriptions).lower()
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        keywords = self.kw_model.extract_keywords(text, keyphrase_ngram_range=(1, 2), stop_words='english', top_n=top_k*2)

        seen = set()
        filtered_keywords = []
        for phrase, _ in keywords:
            main_word = phrase.lower().split()[0]
            if main_word not in seen:
                seen.add(main_word)
                filtered_keywords.append(phrase)
            if len(filtered_keywords) >= top_k:
                break
        return filtered_keywords
