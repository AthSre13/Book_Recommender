import requests

def get_books_from_google(query: str, api_key: str, max_results=20):
    url = f"https://www.googleapis.com/books/v1/volumes?q={query}&maxResults={max_results}&key={api_key}"
    response = requests.get(url)
    books = []
    for item in response.json().get("items", []):
        volume = item['volumeInfo']
        books.append({
            'title': volume.get('title'),
            'authors': volume.get('authors', []),
            'description': volume.get('description', '')
        })
    return books
