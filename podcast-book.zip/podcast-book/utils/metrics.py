from nltk.translate.bleu_score import sentence_bleu
from nltk.translate.meteor_score import meteor_score
from rouge import Rouge

rouge = Rouge()

def evaluate_metrics(references: list[str], predictions: list[str]):
    print("\n--- Evaluation Metrics ---")

    for i, (ref, pred) in enumerate(zip(references, predictions)):
        print(f"\nSample {i+1}:")
        print("Ref:", ref)
        print("Pred:", pred)

        try:
            # BLEU
            bleu = sentence_bleu([ref.split()], pred.split())
            print(f"BLEU: {bleu:.4f}")

            # METEOR
            meteor = meteor_score([ref], pred)
            print(f"METEOR: {meteor:.4f}")

            # ROUGE
            scores = rouge.get_scores(pred, ref)[0]
            print(f"ROUGE-L: {scores['rouge-l']['f']:.4f}")

        except Exception as e:
            print("Error in metric evaluation:", e)
