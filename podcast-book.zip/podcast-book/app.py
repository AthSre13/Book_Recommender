import streamlit as st
import pandas as pd
import numpy as np
import warnings
import re
import matplotlib.pyplot as plt

from agents.profiler_agent import ProfilerAgent
from agents.recommender_agent import RecommenderAgent
from utils.google_books_api import get_books_from_google
from utils.embedding_utils import EmbeddingUtils

from nltk.translate.bleu_score import SmoothingFunction
from sklearn.metrics.pairwise import cosine_similarity

# Suppress warnings
warnings.filterwarnings("ignore")

# ------------------ App Config ------------------
st.set_page_config(
    page_title="Podcast-to-Book Recommender",
    layout="centered",
    initial_sidebar_state="expanded"
)

# ------------------ Constants ------------------
GOOGLE_API_KEY = "AIzaSyCxj2BH2tn7aisQLgtYlvvSJNqM7WBi1E0"
embedding_models = ['all-MiniLM-L6-v2', 'all-mpnet-base-v2']

# ------------------ Load Data ------------------
podcasts_df = pd.read_csv("data/podcasts.csv")

# ------------------ Sidebar ------------------
st.sidebar.title("🎧 Podcast Preferences")
selected = st.sidebar.multiselect(
    "Choose podcasts you like:",
    options=podcasts_df['Name'],
)

descriptions = list(podcasts_df[podcasts_df['Name'].isin(selected)]['Description'])

# ------------------ Utility ------------------
def highlight_keywords(text, keywords):
    for kw in keywords:
        pattern = re.compile(re.escape(kw), re.IGNORECASE)
        text = pattern.sub(f'<span style="background-color: #ffff00">{kw}</span>', text)
    return text

def background_color_div(html_content, color):
    return f"""
    <div style="background-color: {color}; padding: 1rem; border-radius: 10px; margin-bottom: 1rem;">
        {html_content}
    </div>
    """

# ------------------ Main UI ------------------
st.title("AI Book Recommender")
st.markdown("Get book recommendations based on your favorite podcasts using semantic embeddings.")

if st.button("Get Book Recommendations") and descriptions:
    with st.spinner("Finding the best books for you..."):
        model_scores = {}

        for model_name in embedding_models:
            st.markdown(f"<hr>", unsafe_allow_html=True)
            st.markdown(f"### Using embedding model: `{model_name}`")

            # Profiler Agent
            profiler = ProfilerAgent(model_name=model_name)
            user_vector = profiler.generate_user_vector(descriptions)
            keywords = profiler.extract_keywords(descriptions, top_k=10)
            query = ", ".join(set(keywords))
            st.markdown(f" **Search query generated:** `{query}`")

            # Google Books API
            books = get_books_from_google(query, GOOGLE_API_KEY)

            # Embed and recommend
            embedder = EmbeddingUtils(model_name=model_name)
            book_embeddings = embedder.embed_books(books)
            recommender = RecommenderAgent(books, book_embeddings)
            recommendations = recommender.recommend(user_vector)

            # Show Recommendations
            st.subheader(f"Recommended Books:")
            relevance_scores = []
            book_titles = []

            for book in recommendations:
                title = book['title']
                authors = ", ".join(book['authors']) if book['authors'] else "Unknown author"
                description = book['description'] or "No description available."
                thumbnail_url = book.get('imageLinks', {}).get('thumbnail')
                isbn = book.get('industryIdentifiers', [{}])[0].get('identifier')
                amazon_url = f"https://www.amazon.com/dp/{isbn}" if isbn else None

                # Cosine similarity relevance
                book_vector = embedder.model.encode(description, convert_to_tensor=False)
                cos_sim = cosine_similarity([user_vector], [book_vector])[0][0]
                relevance_score = int(cos_sim * 100)
                relevance_scores.append(relevance_score)
                book_titles.append(title)

                if relevance_score >= 60:
                    bg_color = "#d4edda" 
                    label = "Highly Relevant"
                elif relevance_score >= 40:
                    bg_color = "#fff3cd"  
                    label = "Moderately Relevant"
                else:
                    bg_color = "#f8d7da"  
                    label = "Less Relevant"

                highlighted_description = highlight_keywords(description, keywords)

                # Generate HTML content
                html_content = f"""
    <div style="display: flex; font-family: sans-serif;">
        {'<img src="' + thumbnail_url + '" style="height: 120px; margin-right: 1rem;">' if thumbnail_url else ''}
        <div>
            <h4>{title}</h4>
            <p><strong>Authors:</strong> {authors}</p>
            <div style="max-height: 100px; overflow-y: auto; padding-right: 10px;">
                {highlighted_description}
            </div>
            {'<p><a href="' + amazon_url + '">🔗 Buy on Amazon</a></p>' if amazon_url else ''}
            <p><strong>{label}</strong> ({relevance_score}%)</p>
        </div>
    </div>
                """

                st.components.v1.html(background_color_div(html_content, bg_color), height=250)


            # Relevance Bar Graph
            import plotly.express as px

            if book_titles:
                st.subheader("Relevance Score Comparison")
                fig = px.bar(
                    x=relevance_scores,
                    y=book_titles,
                    orientation='h',
                    color=relevance_scores,
                    color_continuous_scale='Blues',
                    labels={'x': 'Relevance Score (%)', 'y': 'Book Title'},
                    title='Book Recommendation Relevance'
                )
                st.plotly_chart(fig, use_container_width=True)


            # Store average relevance score for this model
            avg_score = np.mean(relevance_scores) if relevance_scores else 0
            model_scores[model_name] = avg_score

        # Comparison between models
        
        if len(model_scores) > 1:
            st.markdown("---")
            st.subheader("Model Comparison: Average Relevance Score")
            fig = px.bar(
                x=list(model_scores.keys()),
                y=list(model_scores.values()),
                labels={'x': 'Embedding Model', 'y': 'Avg Relevance Score (%)'},
                color=list(model_scores.values()),
                color_continuous_scale='Viridis',
                title='Model-wise Average Relevance'
            )
            fig.update_layout(yaxis_range=[0, 100])
            st.plotly_chart(fig, use_container_width=True)


elif not descriptions:
    st.info("👈 Select at least one podcast from the sidebar to begin.")
